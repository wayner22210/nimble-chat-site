module.exports = {
  output: 'standalone',
  reactStrictMode: true,
};